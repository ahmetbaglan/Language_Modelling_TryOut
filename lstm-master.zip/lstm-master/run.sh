#!/bin/bash
luajit main.lua
